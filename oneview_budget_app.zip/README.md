# OneView Budget (Flutter)

This project implements the validated home screen and the “Modèle parfait” popup
with 3 animated needle gauges (Épargne, Fixes, Dépenses personnelles).

## Run

```
flutter pub get
flutter run
```

## Build APK

```
flutter build apk --release
```

A codemagic.yaml is included for CI.
